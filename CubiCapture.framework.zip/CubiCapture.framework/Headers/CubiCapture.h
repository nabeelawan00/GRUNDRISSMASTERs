//
//  CubiCapture.h
//  CubiCapture
//
//  Created by CubiCasa Office on 19/06/2019.
//  Copyright © 2019 CubiCasa Office. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CubiCapture.
FOUNDATION_EXPORT double CubiCaptureVersionNumber;

//! Project version string for CubiCapture.
FOUNDATION_EXPORT const unsigned char CubiCaptureVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CubiCapture/PublicHeader.h>


